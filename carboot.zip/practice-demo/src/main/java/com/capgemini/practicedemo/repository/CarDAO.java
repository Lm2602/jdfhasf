package com.capgemini.practicedemo.repository;

import java.util.*;

import com.capgemini.practicedemo.dto.CarDTO;

public interface CarDAO 
{
    public List<CarDTO> findAll(); 
    public CarDTO findById(int id);
    public CarDTO create(CarDTO car);
    public CarDTO update(CarDTO car);
    public CarDTO delete(int id);
}