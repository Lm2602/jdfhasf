package com.example.mptdemorv.service;
import java.util.List;

import com.example.mptdemorv.dto.Customer;

public interface CustomerService {

	public List<Customer> findAll();
	
	public Customer add(Customer customer);
	public Customer findById(int id);

}