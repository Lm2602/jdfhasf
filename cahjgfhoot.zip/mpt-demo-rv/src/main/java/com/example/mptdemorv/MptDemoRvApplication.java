package com.example.mptdemorv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MptDemoRvApplication {

	public static void main(String[] args) {
		SpringApplication.run(MptDemoRvApplication.class, args);
	}

}
