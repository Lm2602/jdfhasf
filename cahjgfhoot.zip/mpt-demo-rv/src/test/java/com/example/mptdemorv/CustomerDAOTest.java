package com.example.mptdemorv;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.mptdemorv.dto.Customer;
import com.example.mptdemorv.service.CustomerService;

import org.springframework.test.context.junit4.SpringRunner;


//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes=MptDemoRvApplication.class)
//@AutoConfigureTestDatabase(replace = Replace.NONE)
//@EnableConfigurationProperties()
//@ContextConfiguration(classes={PersistenceContext.class})
//@DataJpaTest

@RunWith(SpringRunner.class)
@SpringBootTest
public class CustomerDAOTest {

	

	@Autowired
	private CustomerService serRef;
	
	@Test
	public void testFindAll(){
		
		
		List<Customer> customers =serRef.findAll();
		//assertFalse(customers.size()==4);
		assertTrue(customers.size()==4);
		
		 Customer c=serRef.findById(43);
		 assertEquals("Manas", c.getFirstName());
		
		
	}	

}









